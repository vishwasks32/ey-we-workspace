def add(a: int, b: int) -> int : 
    '''Returns addition of two numbers'''
    return a + b


add(2,3)